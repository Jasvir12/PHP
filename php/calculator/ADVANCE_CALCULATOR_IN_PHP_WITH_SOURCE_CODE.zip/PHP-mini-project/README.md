# PHP-mini-project
PHP project for mini calculator.

If you are linux user : 
First install apache2 install php in it, Paste this file into Home/var/www/html/ folder. Then open your browser and type
http://localhost/

If your windows user : 
Install wamp server and go to www directory of it, And create new folder name as Advance_Calculator and paste file into it. 
now open browser and search http://localhost/Advance_Calculator/
